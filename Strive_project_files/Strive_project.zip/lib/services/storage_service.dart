
class StorageService{

}